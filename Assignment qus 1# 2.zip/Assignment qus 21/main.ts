
// 21. They think of something you could store in a TypeScript Object. Write a program that creates Objects containing these items.
// Object containing information about different programming languages
var programmingLanguagesInfo = {
    'JavaScript': { name: 'JavaScript', yearCreated: 1995, creator: 'Brendan Eich' },
    'Python': { name: 'Python', yearCreated: 1991, creator: 'Guido van Rossum' },
    'Java': { name: 'Java', yearCreated: 1995, creator: 'James Gosling' },
    'C++': { name: 'C++', yearCreated: 1985, creator: 'Bjarne Stroustrup' },
    'Ruby': { name: 'Ruby', yearCreated: 1995, creator: 'Yukihiro Matsumoto' }
};
console.log(programmingLanguagesInfo);