
// 7.Favorite Number: Store your favorite number in a variable. Then, using that variable, create a message that reveals your favorite number. Print that message..

// Ans...
let favoriteNumber= 5
let message1:string =" My lucky number is "
console.log(` ${message1} ${favoriteNumber}`)