
// 5.Famous Quote 2 : reapeat ,but this time store the famous person's name in a variabe called famous_person. then compose your message and store it in a new variable called message.Print your message...

// Ans....
let famous_person: string ="HAZRAT ALI "
let message: string ="Accept The Apology, Even If It is not Sincer."
console.log(`${famous_person} Once Said," ${message}"`)