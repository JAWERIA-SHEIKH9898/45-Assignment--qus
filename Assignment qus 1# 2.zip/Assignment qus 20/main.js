// 20.Think of something you could store in a array. For example, you could make a list of mountains, rivers, countries, cities, languages, or anything else you’d like. Write a program that creates a list containing these items.
var citys = ["karachi", "punjab", "lahore", "mirpurkhas", "rawalpindi"];
console.log("city:");
for (var _i = 0, citys_1 = citys; _i < citys_1.length; _i++) {
    var city = citys_1[_i];
    console.log(city);
}
