// 4.Famous Quote:Find a qoute from a famous your admire. Print the quote and the name of its author.Your output should look something like the
// following ,including the quoation marks:
// Albert Einstein once said, "A person who never made a mistake never tried anything news."

// Ans...
let name1:string =("Hazrat Ali said")
console.log(`${name1}, "Each person's Grief Is According To His Courage"`)
