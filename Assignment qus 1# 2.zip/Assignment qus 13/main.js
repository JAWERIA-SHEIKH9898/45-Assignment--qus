// 13.Your Own Array: Think of your favorite mode of transportation, such as a motorcycle or a car, and make a list that stores several examples. Use your list to print a series of statements about these items, such as “I would like to own a Honda motorcycle.”
// Ans...
var transportation = [" Honda Bike", "Carolla Car", "Shiva cycle", "Heavy Bike"];
console.log("I would like to own a ", transportation[0]);
console.log("I would like to own a ", transportation[1]);
console.log("I would like to own a ", transportation[2]);
console.log("I would like to own a ", transportation[3]);
