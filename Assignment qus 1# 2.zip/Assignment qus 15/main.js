// 15 .Changing Guest List: You just heard that one of your guests can’t make the dinner, so you need to send out a new set of invitations. You’ll have to think of someone else to invite.
// • Start with your program from Exercise 14. Add a print statement at the end of your program stating the name of the guest who can’t make it.
// • Modify your list, replacing the name of the guest who can’t make it with the name of the new person you are inviting.
// • Print a second set of invitation messages, one for each person who is still in your list
// Ans...
var initialGuest = ["zara", "jiya", "zuhaa", "wayna", "mona"];
console.log("Old list of nitialGuest is,".concat(initialGuest, "\n "));
console.log(initialGuest[3], "you can't make it");
initialGuest.pop();
initialGuest.push("Aliza");
console.log("Dear!".concat(initialGuest[1], ",\"I invited to you at dinner party\""));
console.log("Dear!".concat(initialGuest[1], ",\"I invited to you at dinner party\""));
console.log("Dear!".concat(initialGuest[3], ",\"I invited to you at dinner party\""));
console.log("Dear!".concat(initialGuest[4], ",\"I invited to you at dinner party\"\n "));
console.log("".concat(initialGuest, ",\"to day i found a big dinner table plz join us:\""));
console.log("".concat(initialGuest, ",\"to day i found a big dinner table plz join us:\""));
console.log("".concat(initialGuest, ",\"to day i found a big dinner table plz join us:\"\n"));
var guest1 = initialGuest.unshift("kainat");
console.log("number of guest has increased to", guest1);
console.log("\"Add a new member \",".concat(initialGuest));
